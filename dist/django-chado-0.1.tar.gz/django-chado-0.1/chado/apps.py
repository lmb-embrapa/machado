from django.apps import AppConfig


class DjangochadoConfig(AppConfig):
    name = 'djangochado'
